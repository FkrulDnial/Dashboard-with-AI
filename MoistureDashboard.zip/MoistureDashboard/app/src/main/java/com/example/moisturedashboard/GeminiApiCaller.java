package com.example.moisturedashboard;

import android.content.Context;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GeminiApiCaller {

    public static void askGemini(Context context, String apiKey, String promptText) {
        new Thread(() -> {
            try {
                OkHttpClient client = new OkHttpClient();

                JSONObject part = new JSONObject();
                part.put("text", promptText);

                JSONArray parts = new JSONArray();
                parts.put(part);

                JSONObject content = new JSONObject();
                content.put("parts", parts);

                JSONArray contents = new JSONArray();
                contents.put(content);

                JSONObject requestBodyJson = new JSONObject();
                requestBodyJson.put("contents", contents);

                MediaType JSON = MediaType.parse("application/json; charset=utf-8");
                RequestBody body = RequestBody.create(JSON, requestBodyJson.toString());

                Request request = new Request.Builder()
                        .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + apiKey)
                        .post(body)
                        .addHeader("Content-Type", "application/json")
                        .build();

                Response response = client.newCall(request).execute();

                if (response.isSuccessful() && response.body() != null) {
                    String responseString = response.body().string();
                    JSONObject json = new JSONObject(responseString);
                    JSONArray candidates = json.getJSONArray("candidates");
                    JSONObject firstCandidate = candidates.getJSONObject(0);
                    JSONObject contentObj = firstCandidate.getJSONObject("content");
                    JSONArray responseParts = contentObj.getJSONArray("parts");
                    String answer = responseParts.getJSONObject(0).getString("text");

                    android.os.Handler handler = new android.os.Handler(context.getMainLooper());
                    handler.post(() -> Toast.makeText(context, answer, Toast.LENGTH_LONG).show());
                } else {
                    android.os.Handler handler = new android.os.Handler(context.getMainLooper());
                    handler.post(() -> Toast.makeText(context, "Gemini API call failed", Toast.LENGTH_SHORT).show());
                }
            } catch (IOException | org.json.JSONException e) {
                e.printStackTrace();
                android.os.Handler handler = new android.os.Handler(context.getMainLooper());
                handler.post(() -> Toast.makeText(context, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }
}
