package com.example.moisturedashboard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private WebView dashboardWebView;
    private ProgressBar progressBar;
    private Button refreshButton, resetButton, geminiButton;
    private FloatingActionButton fabMenu;
    private boolean isMenuOpen = false;

    private final String BASE_URL = "https://lookerstudio.google.com/reporting/976fa1e8-1bb2-4aae-860e-de7cb6b9511b";
    private final String GEMINI_API_KEY = "AIzaSyA20kj-sbpZNBxIg3Ub0LQyqrPaVQgbcao"; // 🔒 Replace with your actual key

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dashboardWebView = findViewById(R.id.dashboardWebView);
        progressBar = findViewById(R.id.progressBar);
        refreshButton = findViewById(R.id.refreshButton);
        resetButton = findViewById(R.id.resetButton);
        geminiButton = findViewById(R.id.geminiButton);
        fabMenu = findViewById(R.id.fabMenu);

        dashboardWebView.getSettings().setJavaScriptEnabled(true);
        dashboardWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
            }
        });

        dashboardWebView.loadUrl(BASE_URL);

        fabMenu.setOnClickListener(v -> toggleMenu());

        refreshButton.setOnClickListener(v -> {
            dashboardWebView.reload();
            toggleMenu();
        });

        resetButton.setOnClickListener(v -> {
            dashboardWebView.loadUrl(BASE_URL);
            toggleMenu();
        });

        geminiButton.setOnClickListener(v -> {
            askGeminiFromJson();
            toggleMenu();
        });
    }

    private void toggleMenu() {
        isMenuOpen = !isMenuOpen;
        int visibility = isMenuOpen ? View.VISIBLE : View.GONE;
        refreshButton.setVisibility(visibility);
        resetButton.setVisibility(visibility);
        geminiButton.setVisibility(visibility);
    }

    private void askGeminiFromJson() {
        new Thread(() -> {
            try {
                InputStream is = getAssets().open("prompt.json");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();

                String jsonString = new String(buffer, StandardCharsets.UTF_8);
                JSONArray jsonArray = new JSONArray(jsonString);
                JSONObject firstObject = jsonArray.getJSONObject(0);
                String jsonOutput = firstObject.getString("JSON Output");

                String prompt = "Please summarize the soil moisture readings ( make it simple but easy to understand ) in this JSON data:\n" + jsonOutput;

                OkHttpClient client = new OkHttpClient();

                JSONObject json = new JSONObject();
                JSONArray contents = new JSONArray();
                JSONObject partObj = new JSONObject();
                partObj.put("text", prompt);
                JSONObject partsWrapper = new JSONObject();
                partsWrapper.put("parts", new JSONArray().put(partObj));
                contents.put(partsWrapper);
                json.put("contents", contents);

                RequestBody body = RequestBody.create(
                        MediaType.parse("application/json"),
                        json.toString()
                );

                Request request = new Request.Builder()
                        .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + GEMINI_API_KEY)
                        .post(body)
                        .build();

                Response response = client.newCall(request).execute();

                if (response.isSuccessful()) {
                    String resStr = response.body().string();
                    JSONObject responseObject = new JSONObject(resStr);
                    JSONArray candidates = responseObject.getJSONArray("candidates");
                    JSONObject first = candidates.getJSONObject(0);
                    JSONObject content = first.getJSONObject("content");
                    JSONArray parts = content.getJSONArray("parts");
                    String answer = parts.getJSONObject(0).getString("text");

                    // Open new activity with result
                    runOnUiThread(() -> {
                        Intent intent = new Intent(MainActivity.this,GeminiResultActivity.class);
                        intent.putExtra("gemini_result", answer);
                        startActivity(intent);
                    });
                } else {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Gemini API failed: " + response.code(), Toast.LENGTH_SHORT).show());
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }


    @Override
    public void onBackPressed() {
        if (dashboardWebView.canGoBack()) {
            dashboardWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
