package com.example.moisturedashboard;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class GeminiResultActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gemini_result);

        TextView resultTextView = findViewById(R.id.resultTextView);
        Button homeButton = findViewById(R.id.homeButton);

        // Get the result from intent
        String geminiResult = getIntent().getStringExtra("gemini_result");
        resultTextView.setText(geminiResult);

        // Home button action
        homeButton.setOnClickListener(v -> {
            Intent intent = new Intent(GeminiResultActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish(); // Optional: close this activity
        });
    }
}
